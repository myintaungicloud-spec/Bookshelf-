/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type BookFileType = 'pdf' | 'epub';

export interface Book {
  id: string;
  fileName: string;
  fileSize: number; // in bytes
  fileType: BookFileType;
  mimeType: string;
  title: string;
  author: string;
  category: string;
  description?: string;
  addedAt: number; // timestamp
  coverColor?: string;
  coverImage?: string;
  isFavorite?: boolean;
  pageCount?: number;
  blob?: Blob;
}

export type BookSortOption = 'newest' | 'oldest' | 'size_desc' | 'size_asc' | 'title_asc';

export type BookFilterType = 'all' | 'pdf' | 'epub' | 'favorites';

export const BOOK_CATEGORIES = [
  'အားလုံး',
  'ဝတ္ထုရှည်',
  'ဝတ္ထုတို',
  'သုတရသ',
  'အတွေးအခေါ်/စာပေ',
  'ဘာသာရေး',
  'သမိုင်း/နိုင်ငံရေး',
  'နည်းပညာ/ဗဟုသုတ',
  'အထွေထွေ',
] as const;
