/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Format bytes to human readable format (KB, MB, GB)
 */
export function formatFileSize(bytes: number): string {
  if (bytes <= 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const val = parseFloat((bytes / Math.pow(k, i)).toFixed(i === 0 ? 0 : 2));
  return `${val} ${sizes[i]}`;
}

/**
 * Converts Western digits 0-9 to Myanmar digits ၀-၉
 */
export function toBurmeseDigits(input: string | number): string {
  const burmeseDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
  return String(input).replace(/[0-9]/g, (match) => burmeseDigits[parseInt(match, 10)]);
}

/**
 * Format timestamp into Myanmar readable date
 */
export function formatBurmeseDate(timestamp: number): string {
  const date = new Date(timestamp);
  const months = [
    'ဇန်နဝါရီ',
    'ဖေဖော်ဝါရီ',
    'မတ်',
    'ဧပြီ',
    'မေ',
    'ဇွန်',
    'ဇူလိုင်',
    'ဩဂုတ်',
    'စက်တင်ဘာ',
    'အောက်တိုဘာ',
    'နိုဝင်ဘာ',
    'ဒီဇင်ဘာ',
  ];
  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  return `${year} ${month} ${day}`;
}

/**
 * Trigger browser file download from Blob
 */
export function downloadBlob(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  setTimeout(() => {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }, 100);
}

/**
 * Creates a valid minimal PDF binary Blob with custom title and text
 * so sample books downloaded by the user are real, valid, working PDFs.
 */
export function createSamplePdfBlob(title: string, author: string, excerpt: string): Blob {
  // A clean minimal valid PDF 1.4 document
  const streamContent = `BT
/F1 18 Tf
50 720 Td
(${escapePdfText(title)}) Tj
0 -30 Td
/F1 12 Tf
(${escapePdfText('Author: ' + author)}) Tj
0 -40 Td
/F1 10 Tf
(${escapePdfText('Kyun-toke-e Sar-ote-sin | Burmese Bookshelf Web App')}) Tj
0 -30 Td
(${escapePdfText(excerpt)}) Tj
ET`;

  const streamLength = streamContent.length;

  const pdf = `%PDF-1.4
1 0 obj
<<
  /Type /Catalog
  /Pages 2 0 R
>>
endobj
2 0 obj
<<
  /Type /Pages
  /Kids [3 0 R]
  /Count 1
>>
endobj
3 0 obj
<<
  /Type /Page
  /Parent 2 0 R
  /MediaBox [0 0 595 842]
  /Contents 4 0 R
  /Resources <<
    /Font <<
      /F1 <<
        /Type /Font
        /Subtype /Type1
        /BaseFont /Helvetica-Bold
      >>
    >>
  >>
>>
endobj
4 0 obj
<<
  /Length ${streamLength}
>>
stream
${streamContent}
endstream
endobj
xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000305 00000 n 
trailer
<<
  /Size 5
  /Root 1 0 R
>>
startxref
${420 + streamLength}
%%EOF`;

  return new Blob([pdf], { type: 'application/pdf' });
}

function escapePdfText(str: string): string {
  return str.replace(/[()\\]/g, '\\$&').replace(/\n/g, ' ');
}

/**
 * Creates a valid minimal EPUB package Blob
 */
export function createSampleEpubBlob(title: string, author: string, content: string): Blob {
  // Clean minimal epub text container
  const htmlContent = `<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>${title}</title>
  <style>
    body { font-family: sans-serif; line-height: 1.8; padding: 2rem; }
    h1 { color: #1e3a8a; }
    .author { font-style: italic; color: #64748b; margin-bottom: 2rem; }
    p { margin-bottom: 1rem; }
  </style>
</head>
<body>
  <h1>${title}</h1>
  <div class="author">${author}</div>
  <p>${content}</p>
</body>
</html>`;

  return new Blob([htmlContent], { type: 'application/epub+zip' });
}
