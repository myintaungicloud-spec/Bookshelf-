/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  ArrowUpDown,
  LayoutGrid,
  List,
  Upload,
  FolderOpen,
  Sparkles,
  CheckCircle,
  Info,
  Heart,
} from 'lucide-react';
import { Book, BookFilterType, BookSortOption, BOOK_CATEGORIES } from './types/book';
import {
  saveBookToDB,
  deleteBookFromDB,
  toggleFavoriteInDB,
  getStorageStats,
  seedSampleBooksIfEmpty,
} from './services/db';
import { downloadBlob, toBurmeseDigits, formatFileSize } from './utils/formatters';
import { Header } from './components/Header';
import { BookRow } from './components/BookRow';
import { BookCard } from './components/BookCard';
import { BookUploadModal } from './components/BookUploadModal';
import { BookReaderModal } from './components/BookReaderModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { InstructionsModal } from './components/InstructionsModal';
import { MobileBottomNav } from './components/MobileBottomNav';

export default function App() {
  const [books, setBooks] = useState<Book[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [totalBytes, setTotalBytes] = useState<number>(0);

  // Dark Mode State
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('bookshelf_theme');
      if (stored) return stored === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Sync Dark Mode with <html> class & localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('bookshelf_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('bookshelf_theme', 'light');
    }
  }, [isDark]);

  const toggleDarkMode = () => {
    setIsDark((prev) => !prev);
  };

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<BookFilterType>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('အားလုံး');
  const [sortBy, setSortBy] = useState<BookSortOption>('newest');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');

  // Modal States
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isInstructionsOpen, setIsInstructionsOpen] = useState<boolean>(false);
  const [readerBook, setReaderBook] = useState<Book | null>(null);
  const [deleteBookTarget, setDeleteBookTarget] = useState<Book | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Toast Feedback State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 3000);
  };

  // Load books from IndexedDB on initial mount
  const loadBooksFromDB = async () => {
    try {
      setIsLoading(true);
      const loadedBooks = await seedSampleBooksIfEmpty();
      setBooks(loadedBooks);

      const stats = await getStorageStats();
      setTotalBytes(stats.totalBytes);
    } catch (err) {
      console.error('Failed to load books from IndexedDB:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBooksFromDB();
  }, []);

  // Save book handler
  const handleSaveBook = async (newBook: Book) => {
    await saveBookToDB(newBook);
    setBooks((prev) => [newBook, ...prev]);
    const stats = await getStorageStats();
    setTotalBytes(stats.totalBytes);
    showToast(`“${newBook.title}” စာအုပ်ကို စာအုပ်စင်ထဲသို့ အောင်မြင်စွာ ထည့်သွင်းပြီးပါပြီ`);
  };

  // Download handler
  const handleDownloadBook = (book: Book) => {
    if (book.blob) {
      downloadBlob(book.blob, book.fileName);
      showToast(`“${book.fileName}” ဖိုင်ကို ဒေါင်းလုဒ် ရယူနေပါသည်...`);
    } else {
      showToast('ဖိုင်ဒေတာ ရှာမတွေ့ပါ');
    }
  };

  // Delete handler
  const handleConfirmDelete = async () => {
    if (!deleteBookTarget) return;
    try {
      setIsDeleting(true);
      await deleteBookFromDB(deleteBookTarget.id);
      setBooks((prev) => prev.filter((b) => b.id !== deleteBookTarget.id));
      const stats = await getStorageStats();
      setTotalBytes(stats.totalBytes);
      showToast(`“${deleteBookTarget.title}” စာအုပ်ကို စာအုပ်စင်မှ ဖျက်သိမ်းပြီးပါပြီ`);
      setDeleteBookTarget(null);
    } catch (err) {
      console.error('Failed to delete book:', err);
      showToast('စာအုပ်ဖျက်ရာတွင် အမှားဖြစ်ပေါ်ခဲ့ပါသည်');
    } finally {
      setIsDeleting(false);
    }
  };

  // Favorite toggle handler
  const handleToggleFavorite = async (id: string) => {
    try {
      const isFav = await toggleFavoriteInDB(id);
      setBooks((prev) =>
        prev.map((b) => (b.id === id ? { ...b, isFavorite: isFav } : b))
      );
      showToast(isFav ? 'အကြိုက်ဆုံးစာရင်းထဲသို့ ထည့်သွင်းပြီးပါပြီ' : 'အကြိုက်ဆုံးစာရင်းမှ ဖယ်ရှားလိုက်ပါပြီ');
    } catch (err) {
      console.error('Failed to toggle favorite:', err);
    }
  };

  // Share handler
  const handleShareBook = async (book: Book) => {
    const shareText = `ကျွန်ုပ်တို့၏ စာအုပ်စင် မှ “${book.title}” (${book.author}) စာအုပ် ဖိုင်အရွယ်အစား: ${formatFileSize(book.fileSize)}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: book.title,
          text: shareText,
          url: window.location.href,
        });
      } catch {
        // user cancelled or share failed
      }
    } else {
      await navigator.clipboard.writeText(`${book.title} - ${book.author}\n${window.location.href}`);
      showToast('စာအုပ်အချက်အလက်များကို Clipboard တွင် ကူးယူပြီးပါပြီ');
    }
  };

  // Reset/Re-seed sample books handler
  const handleResetSampleBooks = async () => {
    const freshSamples = await seedSampleBooksIfEmpty();
    setBooks(freshSamples);
    const stats = await getStorageStats();
    setTotalBytes(stats.totalBytes);
    showToast('နမူနာ စာအုပ်များကို ပြန်လည်ထည့်သွင်းပြီးပါပြီ');
  };

  // Filtered & Sorted books calculation
  const filteredBooks = useMemo(() => {
    return books
      .filter((book) => {
        // Format filter
        if (filterType === 'pdf' && book.fileType !== 'pdf') return false;
        if (filterType === 'epub' && book.fileType !== 'epub') return false;
        if (filterType === 'favorites' && !book.isFavorite) return false;

        // Category filter
        if (selectedCategory !== 'အားလုံး' && book.category !== selectedCategory) {
          return false;
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = book.title.toLowerCase().includes(q);
          const matchFileName = book.fileName.toLowerCase().includes(q);
          const matchAuthor = book.author.toLowerCase().includes(q);
          const matchCategory = book.category.toLowerCase().includes(q);
          if (!matchTitle && !matchFileName && !matchAuthor && !matchCategory) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') return b.addedAt - a.addedAt;
        if (sortBy === 'oldest') return a.addedAt - b.addedAt;
        if (sortBy === 'size_desc') return b.fileSize - a.fileSize;
        if (sortBy === 'size_asc') return a.fileSize - b.fileSize;
        if (sortBy === 'title_asc') return a.title.localeCompare(b.title);
        return 0;
      });
  }, [books, filterType, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950 flex flex-col text-stone-900 dark:text-stone-100 pb-20 sm:pb-12 transition-colors duration-200">
      {/* Header */}
      <Header
        bookCount={books.length}
        totalBytes={totalBytes}
        isDark={isDark}
        onToggleDark={toggleDarkMode}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenInstructions={() => setIsInstructionsOpen(true)}
        onResetSamples={handleResetSampleBooks}
      />

      {/* Main Content Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-7 space-y-6">
        {/* Hero Banner for Welcoming & Mobile / Desktop Introduction */}
        <section className="relative overflow-hidden rounded-2xl sm:rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xs bg-stone-900 dark:bg-stone-900/90 text-white">
          <img
            src="/src/assets/images/burmese_library_banner_1794164584896.jpg"
            alt="စာအုပ်စင် ပြခန်း"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-35"
          />
          <div className="relative z-10 p-5 sm:p-8 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold backdrop-blur-xs mb-3 border border-amber-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>မြန်မာဘာသာ စာအုပ်စင်နှင့် ဖတ်ရှုစနစ်</span>
            </div>
            <h2 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white mb-2 leading-snug">
              PDF နှင့် EPUB စာအုပ်များကို ဖုန်းထဲတွင် လွယ်ကူစွာ သိမ်းဆည်း၊ မျှဝေ၊ ဖတ်ရှုပါ
            </h2>
            <p className="text-xs sm:text-sm text-stone-300 mb-5 leading-relaxed">
              အင်တာနက်မရှိဘဲ ဖုန်းထဲတွင် အမြဲရှိနေစေရန် Browser IndexedDB ဖြင့် သိမ်းဆည်းပေးပါသည်။ မည်သည့်ဖိုင်ကိုမဆို ချက်ချင်းရှာဖွေ၊ ဖတ်ရှု၊ ဒေါင်းလုဒ် ပြုလုပ်နိုင်ပါသည်။
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setIsUploadOpen(true)}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 active:scale-[0.98] text-white font-semibold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>စာအုပ်အသစ် တင်သွင်းရန်</span>
              </button>

              <button
                type="button"
                onClick={() => setIsInstructionsOpen(true)}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-xs text-white text-xs sm:text-sm font-medium transition-colors cursor-pointer"
              >
                အသုံးပြုနည်း ဖတ်ရန်
              </button>
            </div>
          </div>
        </section>

        {/* Search, Filter Tabs & Sort Controls Toolbar */}
        <section className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-4 shadow-xs space-y-4">
          {/* Search Input Row */}
          <div className="relative">
            <Search className="w-5 h-5 text-stone-400 dark:text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="စာအုပ်အမည်၊ ဖိုင်အမည်၊ စာရေးဆရာ သို့မဟုတ် အမျိုးအစား ရှာဖွေပါ..."
              className="w-full pl-11 pr-10 py-3 rounded-xl border border-stone-200 dark:border-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-900/30 dark:focus:ring-amber-500/30 focus:border-amber-900 dark:focus:border-amber-500 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500 bg-stone-50/50 dark:bg-stone-800/60"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 min-h-[32px] px-2 cursor-pointer"
              >
                ရှင်းမည်
              </button>
            )}
          </div>

          {/* Filter Bar & View Toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
            {/* Format Segmented Tabs */}
            <div className="flex items-center gap-1 p-1 bg-stone-100 dark:bg-stone-800 rounded-xl overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                အားလုံး ({toBurmeseDigits(books.length)})
              </button>
              <button
                type="button"
                onClick={() => setFilterType('pdf')}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  filterType === 'pdf'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                PDF စာအုပ်များ
              </button>
              <button
                type="button"
                onClick={() => setFilterType('epub')}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  filterType === 'epub'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                EPUB စာအုပ်များ
              </button>
              <button
                type="button"
                onClick={() => setFilterType('favorites')}
                className={`min-h-[36px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                  filterType === 'favorites'
                    ? 'bg-white dark:bg-stone-700 text-rose-600 dark:text-rose-400 shadow-xs'
                    : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                <Heart className="w-3.5 h-3.5 fill-rose-500" />
                <span>အကြိုက်ဆုံးများ</span>
              </button>
            </div>

            {/* Category, Sort, and View Mode */}
            <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
              {/* Category Dropdown */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="min-h-[36px] px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 text-xs font-medium text-stone-700 dark:text-stone-200 bg-white dark:bg-stone-800 focus:outline-none focus:ring-1 focus:ring-amber-900 dark:focus:ring-amber-500 cursor-pointer"
              >
                {BOOK_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>

              {/* Sort By Dropdown */}
              <div className="flex items-center gap-1 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg px-2 py-1">
                <ArrowUpDown className="w-3.5 h-3.5 text-stone-400 dark:text-stone-500" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as BookSortOption)}
                  className="text-xs font-medium text-stone-700 dark:text-stone-200 bg-transparent focus:outline-none pr-1 cursor-pointer"
                >
                  <option value="newest" className="bg-white dark:bg-stone-800">အသစ်ဆုံး အရင်</option>
                  <option value="oldest" className="bg-white dark:bg-stone-800">အဟောင်းဆုံး အရင်</option>
                  <option value="size_desc" className="bg-white dark:bg-stone-800">ဖိုင်အရွယ်အစား (ကြီးရာမှ ငယ်ရာ)</option>
                  <option value="size_asc" className="bg-white dark:bg-stone-800">ဖိုင်အရွယ်အစား (ငယ်ရာမှ ကြီးရာ)</option>
                  <option value="title_asc" className="bg-white dark:bg-stone-800">နာမည် အက္ခရာစဉ် (က-အ)</option>
                </select>
              </div>

              {/* View Switcher (List vs Grid) */}
              <div className="flex items-center gap-0.5 p-0.5 bg-stone-100 dark:bg-stone-800 rounded-lg border border-stone-200 dark:border-stone-700">
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    viewMode === 'list'
                      ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-2xs'
                      : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                  }`}
                  title="စာရင်းပုံစံ ကြည့်မည် (List View)"
                  aria-label="စာရင်းပုံစံ ကြည့်မည်"
                >
                  <List className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer ${
                    viewMode === 'grid'
                      ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-2xs'
                      : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white'
                  }`}
                  title="ကတ်ပုံစံ ကြည့်မည် (Grid View)"
                  aria-label="ကတ်ပုံစံ ကြည့်မည်"
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Books List / Grid Section */}
        <section className="space-y-3">
          {/* Section Heading & Result count */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                တင်ထားသော စာအုပ်များ
              </h2>
              <span className="text-xs text-stone-500 dark:text-stone-400">
                ({toBurmeseDigits(filteredBooks.length)} အုပ် တွေ့ရှိပါသည်)
              </span>
            </div>

            {searchQuery && (
              <span className="text-xs text-stone-500 dark:text-stone-400">
                ရှာဖွေမှု: <span className="font-semibold text-stone-800 dark:text-stone-200">"{searchQuery}"</span>
              </span>
            )}
          </div>

          {/* Loading State */}
          {isLoading ? (
            <div className="p-12 text-center bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800">
              <div className="w-8 h-8 border-3 border-amber-900/30 dark:border-amber-400/30 border-t-amber-900 dark:border-t-amber-400 rounded-full animate-spin mx-auto mb-3" />
              <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400">
                စာအုပ်စင်အား ရှာဖွေနေပါသည်...
              </p>
            </div>
          ) : filteredBooks.length === 0 ? (
            /* Empty State */
            <div className="p-8 sm:p-12 text-center bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 shadow-xs">
              <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950/50 text-amber-900 dark:text-amber-300 mx-auto flex items-center justify-center mb-4">
                <FolderOpen className="w-8 h-8" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 mb-1">
                စာအုပ်များ မတွေ့ရှိပါ
              </h3>
              <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 max-w-md mx-auto mb-5">
                {searchQuery
                  ? `"${searchQuery}" နှင့် ကိုက်ညီသော စာအုပ် မရှိပါ။ အခြားစာလုံးဖြင့် ပြန်လည်ရှာဖွေကြည့်ပါ။`
                  : 'စာအုပ်စင်ထဲတွင် စာအုပ်များ မရှိသေးပါ။ အသစ်တင်သွင်းပါ သို့မဟုတ် နမူနာစာအုပ်များကို စမ်းသပ်ထည့်သွင်းပါ။'}
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsUploadOpen(true)}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-amber-900 dark:bg-amber-700 hover:bg-amber-950 dark:hover:bg-amber-600 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>စာအုပ်အသစ် တင်မည်</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetSampleBooks}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 text-xs sm:text-sm font-medium transition-colors cursor-pointer"
                >
                  နမူနာစာအုပ်များ ထည့်ရန်
                </button>
              </div>
            </div>
          ) : viewMode === 'list' ? (
            /* List View */
            <div className="space-y-2.5">
              {filteredBooks.map((book) => (
                <BookRow
                  key={book.id}
                  book={book}
                  onDownload={handleDownloadBook}
                  onDelete={(b) => setDeleteBookTarget(b)}
                  onRead={(b) => setReaderBook(b)}
                  onToggleFavorite={handleToggleFavorite}
                  onShare={handleShareBook}
                />
              ))}
            </div>
          ) : (
            /* Grid View */
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filteredBooks.map((book) => (
                <BookCard
                  key={book.id}
                  book={book}
                  onDownload={handleDownloadBook}
                  onDelete={(b) => setDeleteBookTarget(b)}
                  onRead={(b) => setReaderBook(b)}
                  onToggleFavorite={handleToggleFavorite}
                  onShare={handleShareBook}
                />
              ))}
            </div>
          )}
        </section>

        {/* Informative Footer Card with IndexedDB Status & Reload Option */}
        <section className="bg-stone-100/80 dark:bg-stone-900/80 rounded-2xl p-4 border border-stone-200/80 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-400 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-stone-500 dark:text-stone-400 shrink-0" />
            <span>
              စာအုပ်များအား သင့်စက်၏ Browser IndexedDB တွင် သိမ်းဆည်းထားပါသည်။ Refresh လုပ်ပါကလည်း ပျောက်ပျက်မသွားပါ။
            </span>
          </div>
          <button
            type="button"
            onClick={handleResetSampleBooks}
            className="text-amber-900 dark:text-amber-400 hover:underline font-semibold self-start sm:self-auto cursor-pointer"
          >
            နမူနာစာအုပ်များ ပြန်လည်ယူရန်
          </button>
        </section>
      </main>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-6 right-4 left-4 sm:left-auto sm:max-w-md z-50 animate-in slide-in-from-bottom duration-200">
          <div className="bg-stone-900 dark:bg-stone-800 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-stone-700 dark:border-stone-600 text-xs sm:text-sm">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="flex-1 leading-normal">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Upload Modal */}
      <BookUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onSaveBook={handleSaveBook}
      />

      {/* In-App Reader Modal (PDF & EPUB) */}
      <BookReaderModal
        book={readerBook}
        isOpen={Boolean(readerBook)}
        onClose={() => setReaderBook(null)}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        book={deleteBookTarget}
        isOpen={Boolean(deleteBookTarget)}
        onClose={() => setDeleteBookTarget(null)}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />

      {/* Instructions / Help Modal */}
      <InstructionsModal
        isOpen={isInstructionsOpen}
        onClose={() => setIsInstructionsOpen(false)}
      />

      {/* Mobile Fixed Bottom Navigation */}
      <MobileBottomNav
        activeTab={filterType}
        isDark={isDark}
        onToggleDark={toggleDarkMode}
        onSelectShelf={() => setFilterType('all')}
        onSelectFavorites={() => setFilterType('favorites')}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenInstructions={() => setIsInstructionsOpen(true)}
      />
    </div>
  );
}
