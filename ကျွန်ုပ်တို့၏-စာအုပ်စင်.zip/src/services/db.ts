/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Book } from '../types/book';
import { createSamplePdfBlob, createSampleEpubBlob } from '../utils/formatters';

const DB_NAME = 'BurmeseBookShelfDB';
const DB_VERSION = 1;
const STORE_NAME = 'books';

/**
 * Open and initialize IndexedDB
 */
export function openBookDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('addedAt', 'addedAt', { unique: false });
        store.createIndex('fileType', 'fileType', { unique: false });
        store.createIndex('category', 'category', { unique: false });
        store.createIndex('title', 'title', { unique: false });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Fetch all stored books from IndexedDB
 */
export async function getAllBooks(): Promise<Book[]> {
  const db = await openBookDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();

    request.onsuccess = () => {
      const books: Book[] = request.result || [];
      // Sort newest first by default
      books.sort((a, b) => b.addedAt - a.addedAt);
      resolve(books);
    };

    request.onerror = () => reject(request.error);
  });
}

/**
 * Save or update a book in IndexedDB
 */
export async function saveBookToDB(book: Book): Promise<string> {
  const db = await openBookDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(book);

    request.onsuccess = () => resolve(book.id);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Delete a book by ID from IndexedDB
 */
export async function deleteBookFromDB(id: string): Promise<void> {
  const db = await openBookDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Toggle favorite status
 */
export async function toggleFavoriteInDB(id: string): Promise<boolean> {
  const db = await openBookDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const getReq = store.get(id);

    getReq.onsuccess = () => {
      const book: Book = getReq.result;
      if (!book) {
        reject(new Error('Book not found'));
        return;
      }
      book.isFavorite = !book.isFavorite;
      const putReq = store.put(book);
      putReq.onsuccess = () => resolve(book.isFavorite ?? false);
      putReq.onerror = () => reject(putReq.error);
    };

    getReq.onerror = () => reject(getReq.error);
  });
}

/**
 * Calculate total stored books and storage size
 */
export async function getStorageStats(): Promise<{ count: number; totalBytes: number }> {
  const books = await getAllBooks();
  const totalBytes = books.reduce((acc, curr) => acc + (curr.fileSize || 0), 0);
  return {
    count: books.length,
    totalBytes,
  };
}

/**
 * Seeds initial curated Burmese sample books if DB is empty
 */
export async function seedSampleBooksIfEmpty(): Promise<Book[]> {
  const existing = await getAllBooks();
  if (existing.length > 0) {
    return existing;
  }

  const sampleBooks: Book[] = [
    {
      id: 'sample-pagan-blossoms',
      fileName: 'ပုဂံရွှေပန်းခိုင်_မောင်ထွန်းအောင်.pdf',
      fileSize: 1024 * 1024 * 2.4, // ~2.4 MB
      fileType: 'pdf',
      mimeType: 'application/pdf',
      title: 'ပုဂံရွှေပန်းခိုင်',
      author: 'မောင်ထွန်းအောင်',
      category: 'ဝတ္ထုရှည်',
      description: 'ရှေးခေတ်ပုဂံခေတ်၏ ယဉ်ကျေးမှု၊ သမိုင်းကြောင်းနှင့် ချစ်ကြည်ရင်းနှီးမှုတို့ကို ရသမြောက်စွာ ရေးဖွဲ့ထားသော ဂန္ထဝင်ဝတ္ထုကြီး။',
      addedAt: Date.now() - 1000 * 60 * 60 * 24 * 3, // 3 days ago
      coverColor: '#1e3a8a',
      coverImage: '/src/assets/images/burmese_classic_novel_1794164585135.jpg',
      isFavorite: true,
      blob: createSamplePdfBlob(
        'The Golden Blossoms of Pagan',
        'Maung Htun Aung',
        'Pagan ancient heritage, literature and rich historical cultural journey of Myanmar.'
      ),
    },
    {
      id: 'sample-nature-of-growth',
      fileName: 'သဘာဝတရားနှင့်_ကြီးထွားခြင်း.epub',
      fileSize: 1024 * 840, // ~840 KB
      fileType: 'epub',
      mimeType: 'application/epub+zip',
      title: 'သဘာဝတရားနှင့် ကြီးထွားခြင်း',
      author: 'ဆရာမ ဒေါ်သုခမာလာ',
      category: 'အတွေးအခေါ်/စာပေ',
      description: 'လူငယ်များ ဘဝခရီးလမ်းတွင် စိတ်ဓာတ်ခွန်အားဖြစ်စေမည့် အလေ့အကျင့်ကောင်းများ၊ သဘာဝတရား၏ သင်ခန်းစာများနှင့် အတွေးအမြင်များ။',
      addedAt: Date.now() - 1000 * 60 * 60 * 24 * 1, // 1 day ago
      coverColor: '#15803d',
      coverImage: '/src/assets/images/burmese_wisdom_book_1794164584142.jpg',
      isFavorite: false,
      blob: createSampleEpubBlob(
        'The Nature of Growth',
        'Daw Thukhamalar',
        'Finding harmony, balance, mindfulness, and lifelong self-improvement in an ever-changing world.'
      ),
    },
    {
      id: 'sample-peace-of-mind',
      fileName: 'စိတ်အေးချမ်းရာ_မင်္ဂလာတရားတော်များ.pdf',
      fileSize: 1024 * 1024 * 1.6, // ~1.6 MB
      fileType: 'pdf',
      mimeType: 'application/pdf',
      title: 'စိတ်အေးချမ်းရာ မင်္ဂလာတရားတော်များ',
      author: 'အရှင်ဇနကာဘိဝံသ (ဩဝါဒကထာ)',
      category: 'ဘာသာရေး',
      description: 'နေ့စဉ်ဘဝတွင် ရိုးရှင်းအေးချမ်းစွာ နေထိုင်နည်း၊ မင်္ဂလာတရား ၃၈ ဖြာနှင့် ကိုယ်ကျင့်တရား မြှင့်တင်ရေး လမ်းညွှန်ချက်များ။',
      addedAt: Date.now() - 1000 * 60 * 60 * 12, // 12 hours ago
      coverColor: '#b45309',
      isFavorite: true,
      blob: createSamplePdfBlob(
        'Peace of Mind and 38 Blessings',
        'Ashin Janakabhivamsa',
        'Daily mindfulness and virtuous guidelines for inner peace, moral ethics and spiritual growth.'
      ),
    },
  ];

  for (const b of sampleBooks) {
    await saveBookToDB(b);
  }

  return sampleBooks;
}
