/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Download, Trash2, BookOpen, Heart, FileText, Share2 } from 'lucide-react';
import { Book } from '../types/book';
import { formatFileSize, formatBurmeseDate } from '../utils/formatters';

interface BookRowProps {
  book: Book;
  onDownload: (book: Book) => void;
  onDelete: (book: Book) => void;
  onRead: (book: Book) => void;
  onToggleFavorite: (id: string) => void;
  onShare: (book: Book) => void;
}

export const BookRow: React.FC<BookRowProps> = ({
  book,
  onDownload,
  onDelete,
  onRead,
  onToggleFavorite,
  onShare,
}) => {
  const isPdf = book.fileType === 'pdf';

  return (
    <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 p-4 transition-all hover:border-stone-300 dark:hover:border-stone-700 hover:shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
        {/* Left Side: Thumbnail / Icon + Title & File Details */}
        <div className="flex items-start gap-3.5 min-w-0 flex-1">
          {/* Book Icon / Thumbnail */}
          <div
            onClick={() => onRead(book)}
            className="w-12 h-16 rounded-lg shrink-0 flex flex-col items-center justify-between p-1.5 shadow-xs cursor-pointer transition-transform hover:scale-105"
            style={{ backgroundColor: book.coverColor || '#1e3a8a' }}
            title="ဖတ်ရှုရန် နှိပ်ပါ"
          >
            <span className="text-[9px] font-bold tracking-wider uppercase text-white/90">
              {book.fileType}
            </span>
            <FileText className="w-5 h-5 text-white/80" />
            <div className="w-full h-1 bg-white/20 rounded-full" />
          </div>

          {/* Book Info */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                  isPdf
                    ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/50'
                    : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/50'
                }`}
              >
                {book.fileType.toUpperCase()}
              </span>
              <span className="text-xs text-stone-500 dark:text-stone-400 font-medium">
                {book.category}
              </span>
              <span className="text-stone-300 dark:text-stone-700 text-xs">·</span>
              <span className="text-xs text-stone-400 dark:text-stone-500">
                {formatBurmeseDate(book.addedAt)}
              </span>
            </div>

            {/* Book Title */}
            <h3
              onClick={() => onRead(book)}
              className="text-base font-bold text-stone-900 dark:text-stone-100 truncate hover:text-amber-800 dark:hover:text-amber-400 cursor-pointer transition-colors"
            >
              {book.title}
            </h3>

            {/* Author */}
            <p className="text-xs text-stone-600 dark:text-stone-300 truncate mb-1.5">
              စာရေးဆရာ: <span className="font-medium text-stone-800 dark:text-stone-200">{book.author}</span>
            </p>

            {/* File Name & File Size display */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-stone-950/60 rounded-lg px-2.5 py-1.5 border border-stone-200/70 dark:border-stone-800/80">
              <div className="truncate max-w-[200px] sm:max-w-[320px]">
                <span className="font-medium text-stone-700 dark:text-stone-300">ဖိုင်အမည်: </span>
                <span className="text-stone-600 dark:text-stone-400 font-mono text-[11px]">{book.fileName}</span>
              </div>
              <span className="text-stone-300 dark:text-stone-700">|</span>
              <div className="shrink-0">
                <span className="font-medium text-stone-700 dark:text-stone-300">ဖိုင်အရွယ်အစား: </span>
                <span className="font-semibold text-stone-800 dark:text-stone-200 tabular-nums">
                  {formatFileSize(book.fileSize)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Action Buttons */}
        <div className="flex items-center justify-end gap-1.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100 dark:border-stone-800 shrink-0">
          {/* Favorite Toggle */}
          <button
            type="button"
            onClick={() => onToggleFavorite(book.id)}
            className={`min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center transition-colors ${
              book.isFavorite
                ? 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 dark:hover:bg-rose-900/50'
                : 'text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
            title={book.isFavorite ? 'အကြိုက်ဆုံးမှ ဖယ်ထုတ်မည်' : 'အကြိုက်ဆုံးအဖြစ် မှတ်မည်'}
            aria-label="အကြိုက်ဆုံး"
          >
            <Heart className={`w-5 h-5 ${book.isFavorite ? 'fill-rose-500' : ''}`} />
          </button>

          {/* Share Button */}
          <button
            type="button"
            onClick={() => onShare(book)}
            className="min-h-[44px] min-w-[44px] rounded-xl text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center justify-center transition-colors"
            title="စာအုပ် မျှဝေမည်"
            aria-label="စာအုပ် မျှဝေမည်"
          >
            <Share2 className="w-5 h-5" />
          </button>

          {/* Read / Preview Button */}
          <button
            type="button"
            onClick={() => onRead(book)}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="စာအုပ် ဖတ်ရှုရန်"
          >
            <BookOpen className="w-4 h-4 text-stone-600 dark:text-stone-400" />
            <span>ဖတ်မည်</span>
          </button>

          {/* Download Button */}
          <button
            type="button"
            onClick={() => onDownload(book)}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-amber-900 dark:bg-amber-700 hover:bg-amber-950 dark:hover:bg-amber-600 text-white text-xs font-semibold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="ဖိုင်ဒေါင်းလုဒ် ရယူရန်"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">ဒေါင်းလုဒ်</span>
          </button>

          {/* Delete Button */}
          <button
            type="button"
            onClick={() => onDelete(book)}
            className="min-h-[44px] min-w-[44px] rounded-xl text-stone-400 dark:text-stone-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center justify-center transition-colors cursor-pointer"
            title="စာအုပ် ဖျက်မည်"
            aria-label="စာအုပ် ဖျက်မည်"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
