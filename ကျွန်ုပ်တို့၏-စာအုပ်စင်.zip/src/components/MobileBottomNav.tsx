/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Upload, Heart, HelpCircle, Sun, Moon } from 'lucide-react';
import { BookFilterType } from '../types/book';

interface MobileBottomNavProps {
  activeTab: BookFilterType | 'instructions' | 'upload';
  isDark: boolean;
  onToggleDark: () => void;
  onSelectShelf: () => void;
  onSelectFavorites: () => void;
  onOpenUpload: () => void;
  onOpenInstructions: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  isDark,
  onToggleDark,
  onSelectShelf,
  onSelectFavorites,
  onOpenUpload,
  onOpenInstructions,
}) => {
  return (
    <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-t border-stone-200 dark:border-stone-800 shadow-lg pb-safe transition-colors duration-200">
      <div className="grid grid-cols-5 items-center h-16 px-1">
        {/* Shelf Tab */}
        <button
          onClick={onSelectShelf}
          className={`flex flex-col items-center justify-center min-h-[44px] py-1 transition-colors cursor-pointer ${
            activeTab === 'all' || activeTab === 'pdf' || activeTab === 'epub'
              ? 'text-amber-900 dark:text-amber-400 font-bold'
              : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
          }`}
        >
          <BookOpen className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">စာအုပ်စင်</span>
        </button>

        {/* Favorites Tab */}
        <button
          onClick={onSelectFavorites}
          className={`flex flex-col items-center justify-center min-h-[44px] py-1 transition-colors cursor-pointer ${
            activeTab === 'favorites'
              ? 'text-rose-600 dark:text-rose-400 font-bold'
              : 'text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100'
          }`}
        >
          <Heart className={`w-5 h-5 mb-0.5 ${activeTab === 'favorites' ? 'fill-rose-500' : ''}`} />
          <span className="text-[10px] tracking-tight">အကြိုက်</span>
        </button>

        {/* Upload Action */}
        <button
          onClick={onOpenUpload}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 transition-colors cursor-pointer"
        >
          <div className="w-9 h-9 rounded-full bg-amber-900 dark:bg-amber-700 text-white flex items-center justify-center shadow-xs -mt-3.5 border-2 border-white dark:border-stone-900">
            <Upload className="w-4 h-4" />
          </div>
          <span className="text-[10px] tracking-tight mt-0.5 font-medium">တင်မည်</span>
        </button>

        {/* Dark Mode Toggle on Mobile */}
        <button
          onClick={onToggleDark}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 transition-colors cursor-pointer"
          title={isDark ? 'နေ့ခင်းမုဒ်သို့ ပြောင်းမည်' : 'ညခင်းမုဒ်သို့ ပြောင်းမည်'}
        >
          {isDark ? (
            <Sun className="w-5 h-5 mb-0.5 text-amber-400" />
          ) : (
            <Moon className="w-5 h-5 mb-0.5" />
          )}
          <span className="text-[10px] tracking-tight">{isDark ? 'နေ့ခင်း' : 'ညခင်း'}</span>
        </button>

        {/* Instructions Tab */}
        <button
          onClick={onOpenInstructions}
          className="flex flex-col items-center justify-center min-h-[44px] py-1 text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">လမ်းညွှန်</span>
        </button>
      </div>
    </nav>
  );
};
