/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, ChangeEvent, DragEvent } from 'react';
import { X, UploadCloud, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { Book, BOOK_CATEGORIES, BookFileType } from '../types/book';
import { formatFileSize } from '../utils/formatters';

interface BookUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveBook: (book: Book) => Promise<void>;
}

const COLOR_OPTIONS = [
  { name: 'Royal Blue', value: '#1e3a8a' },
  { name: 'Warm Amber', value: '#b45309' },
  { name: 'Forest Emerald', value: '#15803d' },
  { name: 'Burgundy Crimson', value: '#881337' },
  { name: 'Deep Plum', value: '#581c87' },
  { name: 'Slate Teak', value: '#334155' },
];

export const BookUploadModal: React.FC<BookUploadModalProps> = ({
  isOpen,
  onClose,
  onSaveBook,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [category, setCategory] = useState<string>('ဝတ္ထုရှည်');
  const [description, setDescription] = useState('');
  const [coverColor, setCoverColor] = useState('#1e3a8a');
  const [isDragging, setIsDragging] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileProcess = (file: File) => {
    setErrorMsg('');
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext !== 'pdf' && ext !== 'epub') {
      setErrorMsg('ကျေးဇူးပြု၍ PDF (.pdf) သို့မဟုတ် EPUB (.epub) ဖိုင်ကိုသာ ရွေးချယ်ပေးပါ။');
      return;
    }

    setSelectedFile(file);

    // Auto set title if not already modified
    const cleanTitle = file.name.replace(/\.(pdf|epub)$/i, '').replace(/[_-]/g, ' ');
    setTitle(cleanTitle);
  };

  const onFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileProcess(e.target.files[0]);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      setErrorMsg('ကျေးဇူးပြု၍ ဖိုင်တစ်ခု ရွေးချယ်ပေးပါ');
      return;
    }
    if (!title.trim()) {
      setErrorMsg('ကျေးဇူးပြု၍ စာအုပ်အမည် ဖြည့်စွက်ပါ');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');

      const ext = selectedFile.name.split('.').pop()?.toLowerCase() as BookFileType;
      const fileType: BookFileType = ext === 'epub' ? 'epub' : 'pdf';
      const mimeType = fileType === 'pdf' ? 'application/pdf' : 'application/epub+zip';

      const newBook: Book = {
        id: 'book_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        fileName: selectedFile.name,
        fileSize: selectedFile.size,
        fileType,
        mimeType,
        title: title.trim(),
        author: author.trim() || 'အမည်မသိ စာရေးဆရာ',
        category,
        description: description.trim(),
        addedAt: Date.now(),
        coverColor,
        isFavorite: false,
        blob: selectedFile,
      };

      await onSaveBook(newBook);
      // Reset form
      setSelectedFile(null);
      setTitle('');
      setAuthor('');
      setDescription('');
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'ဖိုင်သိမ်းဆည်းရာတွင် အမှားဖြစ်ပေါ်ခဲ့ပါသည်';
      setErrorMsg(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 dark:bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 rounded-2xl sm:rounded-3xl shadow-xl w-full max-w-lg overflow-hidden border border-stone-200 dark:border-stone-800 my-auto">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
              စာအုပ်အသစ် တင်သွင်းရန်
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              PDF နှင့် EPUB ဖိုင်များကို စာအုပ်စင်ထဲသို့ သိမ်းဆည်းပါ
            </p>
          </div>
          <button
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-400 cursor-pointer"
            aria-label="ပိတ်မည်"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {/* File Picker / Drag Drop */}
          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={onFileInputChange}
              accept=".pdf,.epub,application/pdf,application/epub+zip"
              className="hidden"
            />

            {!selectedFile ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all duration-150 ${
                  isDragging
                    ? 'border-amber-700 bg-amber-50/70 dark:bg-amber-950/40'
                    : 'border-stone-300 dark:border-stone-700 hover:border-amber-700 dark:hover:border-amber-600 hover:bg-stone-50 dark:hover:bg-stone-850'
                }`}
              >
                <div className="w-12 h-12 rounded-full bg-amber-100/70 dark:bg-amber-900/40 text-amber-900 dark:text-amber-300 mx-auto flex items-center justify-center mb-3">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <div className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
                  ဖိုင်ရွေးချယ်ရန် ဤနေရာကို နှိပ်ပါ
                </div>
                <p className="text-xs text-stone-500 dark:text-stone-400 mb-2">
                  သို့မဟုတ် ဖိုင်ကို ဤနေရာသို့ ဆွဲယူထည့်ပါ
                </p>
                <div className="inline-block px-2.5 py-1 bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 rounded-lg text-[11px] font-medium border border-stone-200 dark:border-stone-700">
                  လက်ခံသော ဖိုင်များ: PDF, EPUB
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-10 h-10 rounded-lg bg-amber-900 dark:bg-amber-700 text-white flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-sm font-semibold text-stone-900 dark:text-stone-100 truncate">
                      {selectedFile.name}
                    </div>
                    <div className="text-xs text-stone-600 dark:text-stone-300 flex items-center gap-2">
                      <span className="uppercase font-semibold text-amber-900 dark:text-amber-400">
                        {selectedFile.name.split('.').pop()}
                      </span>
                      <span>·</span>
                      <span>{formatFileSize(selectedFile.size)}</span>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-200 cursor-pointer"
                  aria-label="အခြားဖိုင်ပြောင်းမည်"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Book Metadata Fields */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                စာအုပ်အမည် <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="ဥပမာ - မေတ္တာမိုး၊ ဇာတ်လမ်းရှည်..."
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-900/30 dark:focus:ring-amber-500/30 focus:border-amber-900 dark:focus:border-amber-500 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500 bg-white dark:bg-stone-800"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  စာရေးဆရာ
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="ဥပမာ - ဆရာမြသန်းတင့်"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-900/30 dark:focus:ring-amber-500/30 focus:border-amber-900 dark:focus:border-amber-500 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500 bg-white dark:bg-stone-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  အမျိုးအစား
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-900/30 dark:focus:ring-amber-500/30 focus:border-amber-900 dark:focus:border-amber-500 text-sm text-stone-900 dark:text-stone-100 bg-white dark:bg-stone-800"
                >
                  {BOOK_CATEGORIES.filter((c) => c !== 'အားလုံး').map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                အကျဉ်းချုပ် / မှတ်စု (ရှိပါက)
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                placeholder="စာအုပ်အကြောင်း အကျဉ်းချုပ် သို့မဟုတ် မှတ်စုရေးပါ..."
                className="w-full px-3.5 py-2 rounded-xl border border-stone-300 dark:border-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-900/30 dark:focus:ring-amber-500/30 focus:border-amber-900 dark:focus:border-amber-500 text-sm text-stone-900 dark:text-stone-100 placeholder:text-stone-400 dark:placeholder:text-stone-500 bg-white dark:bg-stone-800 resize-none"
              />
            </div>

            {/* Cover Color Theme */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                မျက်နှာဖုံး အရောင်
              </label>
              <div className="flex items-center gap-2">
                {COLOR_OPTIONS.map((col) => (
                  <button
                    key={col.value}
                    type="button"
                    onClick={() => setCoverColor(col.value)}
                    className={`w-8 h-8 rounded-full transition-transform cursor-pointer flex items-center justify-center ${
                      coverColor === col.value
                        ? 'ring-2 ring-stone-900 dark:ring-white ring-offset-2 dark:ring-offset-stone-900 scale-110'
                        : 'opacity-80 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: col.value }}
                    title={col.name}
                    aria-label={col.name}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900/50 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Submit Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="min-h-[44px] px-4 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 text-sm font-medium transition-colors cursor-pointer"
            >
              မလုပ်တော့ပါ
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !selectedFile}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-amber-900 dark:bg-amber-700 hover:bg-amber-950 dark:hover:bg-amber-600 disabled:opacity-50 disabled:pointer-events-none text-white text-sm font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>သိမ်းဆည်းနေပါသည်...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>စာအုပ်စင်သို့ ထည့်သွင်းမည်</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
