/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Upload, HelpCircle, HardDrive, Moon, Sun } from 'lucide-react';
import { formatFileSize, toBurmeseDigits } from '../utils/formatters';

interface HeaderProps {
  bookCount: number;
  totalBytes: number;
  isDark: boolean;
  onToggleDark: () => void;
  onOpenUpload: () => void;
  onOpenInstructions: () => void;
  onResetSamples: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  bookCount,
  totalBytes,
  isDark,
  onToggleDark,
  onOpenUpload,
  onOpenInstructions,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-b border-stone-200 dark:border-stone-800 shadow-xs transition-colors duration-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between gap-3 sm:gap-4">
          {/* Brand Wordmark Zone */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-800 dark:bg-amber-700 text-amber-50 flex items-center justify-center shadow-xs shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-stone-100 whitespace-nowrap">
                  ကျွန်ုပ်တို့၏ စာအုပ်စင်
                </h1>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400 hidden sm:block">
                PDF နှင့် EPUB စာအုပ်များ မိုဘိုင်းဖုန်းပေါ်တွင် အခမဲ့ သိမ်းဆည်းဖတ်ရှုရာ
              </p>
            </div>
          </div>

          {/* Actions & Storage Status Zone */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Storage stat badge (quiet unboxed text) */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-100/80 dark:bg-stone-800/80 text-xs text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700">
              <HardDrive className="w-3.5 h-3.5 text-stone-500 dark:text-stone-400" />
              <span>စာအုပ် {toBurmeseDigits(bookCount)} အုပ်</span>
              <span className="text-stone-300 dark:text-stone-600">|</span>
              <span>{formatFileSize(totalBytes)}</span>
            </div>

            {/* Dark Mode Toggle Button */}
            <button
              onClick={onToggleDark}
              type="button"
              className="min-h-[44px] min-w-[44px] rounded-xl text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-800/40 cursor-pointer"
              title={isDark ? 'နေ့ခင်းမုဒ် (Light Mode) သို့ ပြောင်းမည်' : 'ညခင်းမုဒ် (Dark Mode) သို့ ပြောင်းမည်'}
              aria-label={isDark ? 'နေ့ခင်းမုဒ်သို့ ပြောင်းမည်' : 'ညခင်းမုဒ်သို့ ပြောင်းမည်'}
            >
              {isDark ? (
                <Sun className="w-5 h-5 text-amber-400" />
              ) : (
                <Moon className="w-5 h-5 text-stone-600" />
              )}
            </button>

            {/* Instructions button */}
            <button
              onClick={onOpenInstructions}
              type="button"
              className="min-h-[44px] min-w-[44px] px-3 py-2 rounded-xl text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center gap-1.5 text-xs sm:text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-800/40 cursor-pointer"
              title="အသုံးပြုနည်း လမ်းညွှန်"
              aria-label="အသုံးပြုနည်း လမ်းညွှန်"
            >
              <HelpCircle className="w-4 h-4 text-stone-500 dark:text-stone-400" />
              <span className="hidden sm:inline">လမ်းညွှန်</span>
            </button>

            {/* Primary Upload CTA Button */}
            <button
              onClick={onOpenUpload}
              type="button"
              className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-900 hover:bg-amber-950 dark:bg-amber-700 dark:hover:bg-amber-600 active:scale-[0.98] text-white flex items-center gap-2 text-xs sm:text-sm font-semibold shadow-xs transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-900/50 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span className="whitespace-nowrap">စာအုပ်တင်မည်</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
