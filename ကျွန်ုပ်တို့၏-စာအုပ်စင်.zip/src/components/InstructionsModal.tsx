/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Smartphone, Database, Terminal, FileCheck, Download, Trash2, Search, HelpCircle } from 'lucide-react';

interface InstructionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstructionsModal: React.FC<InstructionsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 dark:bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 rounded-2xl sm:rounded-3xl shadow-xl w-full max-w-2xl overflow-hidden border border-stone-200 dark:border-stone-800 my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between bg-stone-50 dark:bg-stone-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-900/40 text-amber-900 dark:text-amber-300 flex items-center justify-center">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                အသုံးပြုနည်းနှင့် Run နည်း လမ်းညွှန်
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                “ကျွန်ုပ်တို့၏ စာအုပ်စင်” ဝက်ဘ်ဆိုက်အကြောင်း သိကောင်းစရာများ
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-full flex items-center justify-center text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            aria-label="ပိတ်မည်"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-stone-800 dark:text-stone-200 text-sm">
          {/* Section 1: IndexedDB local storage explanation */}
          <div className="rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 p-4">
            <div className="flex items-center gap-2 text-amber-900 dark:text-amber-300 font-bold text-sm mb-2">
              <Database className="w-4 h-4 text-amber-800 dark:text-amber-400" />
              <span>၁။ ဖိုင်များ သိမ်းဆည်းထားရှိပုံ (IndexedDB စနစ်)</span>
            </div>
            <p className="text-xs text-stone-700 dark:text-stone-300 leading-relaxed mb-2">
              ဤဝက်ဘ်ဆိုက်တွင် တင်ထားသော PDF နှင့် EPUB စာအုပ်များကို သင့်ဖုန်း/ကွန်ပျူတာ Browser အတွင်းရှိ <strong>IndexedDB (ဒေသတွင်း သိမ်းဆည်းမှု စနစ်)</strong> တွင် တိုက်ရိုက်သိမ်းဆည်းပေးထားပါသည်။
            </p>
            <ul className="text-xs text-stone-600 dark:text-stone-400 list-disc list-inside space-y-1">
              <li>အင်တာနက် မရှိသည့် အချိန် (Offline) တွင်လည်း စာအုပ်များကို ဖတ်ရှုဒေါင်းလုဒ် ပြုလုပ်နိုင်ပါသည်။</li>
              <li>Browser ကို Refresh လုပ်ခြင်း သို့မဟုတ် ပိတ်ပြီး ပြန်ဖွင့်ပါကလည်း ဖိုင်များ ပျောက်ပျက်မသွားဘဲ ဆက်လက်တည်ရှိနေမည် ဖြစ်ပါသည်။</li>
              <li>စာရင်းသွင်းရန် အကောင့်ဖွင့်စရာမလိုဘဲ မိမိဖုန်းထဲတွင် လျှို့ဝှက်လုံခြုံစွာ သိမ်းဆည်းထားနိုင်ပါသည်။</li>
            </ul>
          </div>

          {/* Section 2: How to upload and read */}
          <div>
            <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-stone-100 text-sm mb-2.5">
              <FileCheck className="w-4 h-4 text-amber-800 dark:text-amber-400" />
              <span>၂။ စာအုပ်တင်သွင်းခြင်းနှင့် ဖတ်ရှုခြင်း</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
                <div className="font-semibold text-stone-800 dark:text-stone-200 mb-1 flex items-center gap-1.5">
                  <span>စာအုပ်အသစ် တင်ရန်</span>
                </div>
                <p className="text-stone-600 dark:text-stone-400">
                  “စာအုပ်တင်မည်” ခလုတ်ကို နှိပ်၍ မိမိဖုန်းထဲရှိ PDF (.pdf) သို့မဟုတ် EPUB (.epub) ဖိုင်ကို ရွေးချယ်ပြီး အမည်၊ စာရေးဆရာ၊ အမျိုးအစား သတ်မှတ်၍ ထည့်သွင်းနိုင်ပါသည်။
                </p>
              </div>

              <div className="p-3 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700">
                <div className="font-semibold text-stone-800 dark:text-stone-200 mb-1 flex items-center gap-1.5">
                  <span>တိုက်ရိုက် ဖတ်ရှုရန်</span>
                </div>
                <p className="text-stone-600 dark:text-stone-400">
                  စာအုပ်ကတ်ပေါ်ရှိ “ဖတ်မည်” ခလုတ်ကို နှိပ်၍ စာရွက်စာတမ်းကို Browser အတွင်း တိုက်ရိုက် ကြည့်ရှုဖတ်ရှုနိုင်ပါသည်။ စာလုံးအရွယ်အစားနှင့် အလင်းအမှောင် မုဒ်များကိုလည်း ပြောင်းလဲနိုင်ပါသည်။
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: Search, Download, and Delete buttons */}
          <div>
            <div className="flex items-center gap-2 font-bold text-stone-900 dark:text-stone-100 text-sm mb-2.5">
              <Download className="w-4 h-4 text-amber-800 dark:text-amber-400" />
              <span>၃။ ရှာဖွေခြင်း၊ ဒေါင်းလုဒ်ရယူခြင်းနှင့် ဖျက်သိမ်းခြင်း</span>
            </div>
            <div className="space-y-2 text-xs text-stone-600 dark:text-stone-400">
              <div className="flex items-start gap-2">
                <Search className="w-4 h-4 text-stone-500 dark:text-stone-400 shrink-0 mt-0.5" />
                <p>
                  <strong>ရှာဖွေရန်:</strong> စာအုပ်အမည်၊ ဖိုင်အမည်၊ စာရေးဆရာ သို့မဟုတ် အမျိုးအစား စကားလုံးများဖြင့် ချက်ချင်း အလွယ်တကူ ရှာဖွေနိုင်ပါသည်။
                </p>
              </div>
              <div className="flex items-start gap-2">
                <Download className="w-4 h-4 text-amber-800 dark:text-amber-400 shrink-0 mt-0.5" />
                <p>
                  <strong>ဒေါင်းလုဒ်ခလုတ်:</strong> စာအုပ်စင်ထဲရှိ မည်သည့်စာအုပ်ကိုမဆို မိမိစက်ထဲသို့ မူရင်းဖိုင်အဖြစ် ပြန်လည်ဒေါင်းလုဒ် ရယူနိုင်ပါသည်။
                </p>
              </div>
              <div className="flex items-start gap-2">
                <Trash2 className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <p>
                  <strong>ဖျက်မည်ခလုတ်:</strong> မလိုအပ်တော့သော စာအုပ်များကို ဖျက်ပစ်နိုင်ပြီး၊ မှားယွင်းမဖျက်မိစေရန် အတည်ပြုသည့် မက်ဆေ့ခ်ျ ပြသပေးပါမည်။
                </p>
              </div>
            </div>
          </div>

          {/* Section 4: How to run developer / local server */}
          <div className="rounded-2xl bg-stone-900 dark:bg-black/90 text-stone-200 p-4 space-y-3 border border-stone-800">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Terminal className="w-4 h-4" />
              <span>၄။ အက်ပ် Run ပြုလုပ်နည်း (Development & Local Run)</span>
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              စက်တွင်းတွင် ကိုယ်တိုင် စမ်းသပ် run လိုပါက အောက်ပါ terminal commands များကို အသုံးပြုနိုင်ပါသည်-
            </p>
            <div className="bg-black/60 rounded-xl p-3 font-mono text-[11px] sm:text-xs text-emerald-400 space-y-1">
              <div># ၁။ လိုအပ်သော dependencies များကို ထည့်သွင်းပါ</div>
              <div className="text-stone-100">npm install</div>
              <div className="pt-1 text-stone-400"># ၂။ Development Server ကို စတင်ပါ (Port 3000 ဖြင့် run ပါမည်)</div>
              <div className="text-stone-100">npm run dev</div>
            </div>
            <p className="text-xs text-stone-400">
              * ဖုန်းမှ တိုက်ရိုက်ဝင်ရောက်လိုပါက ကွန်ပျူတာနှင့် ဖုန်းကို တူညီသော Wi-Fi ကွန်ရက်တွင် ချိတ်ဆက်ပြီး ကွန်ပျူတာ၏ IP လိပ်စာ (ဥပမာ- <code className="text-amber-300">http://192.168.1.15:3000</code>) ဖြင့် Browser တွင် ဖွင့်လှစ်နိုင်ပါသည်။
            </p>
          </div>

          {/* Section 5: Mobile Add to Home Screen */}
          <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 flex items-start gap-3 text-xs">
            <Smartphone className="w-5 h-5 text-stone-600 dark:text-stone-400 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-stone-900 dark:text-stone-100 mb-0.5">
                ဖုန်း Home Screen တွင် App ကဲ့သို့ ထည့်သွင်းနည်း
              </div>
              <p className="text-stone-600 dark:text-stone-400">
                Chrome သို့မဟုတ် Safari တွင် Menu ကို နှိပ်ပြီး <strong>“Add to Home Screen” (ပင်မမျက်နှာပြင်သို့ ထည့်ပါ)</strong> ကို ရွေးချယ်ခြင်းဖြင့် မိုဘိုင်း App တစ်ခုကဲ့သို့ အချိန်မရွေး အလွယ်တကူ ဖွင့်လှစ် အသုံးပြုနိုင်ပါသည်။
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-stone-50 dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-stone-900 dark:bg-stone-800 hover:bg-stone-800 dark:hover:bg-stone-700 text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
          >
            နားလည်ပါပြီ
          </button>
        </div>
      </div>
    </div>
  );
};
