/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertTriangle, Trash2 } from 'lucide-react';
import { Book } from '../types/book';
import { formatFileSize } from '../utils/formatters';

interface DeleteConfirmModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>;
  isDeleting: boolean;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  book,
  isOpen,
  onClose,
  onConfirm,
  isDeleting,
}) => {
  if (!isOpen || !book) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 dark:bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 rounded-2xl sm:rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-stone-200 dark:border-stone-800 my-auto">
        {/* Header */}
        <div className="p-5 flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>

          <div className="flex-1">
            <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 mb-1">
              စာအုပ် ဖျက်ပစ်ရန် အတည်ပြုပါ
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 mb-3">
              အောက်ပါ စာအုပ်ကို သင့်ဖုန်း၏ စာအုပ်စင် (IndexedDB) ထဲမှ အပြီးတိုင် ဖျက်ပစ်ရန် သေချာပါသလား?
            </p>

            <div className="bg-stone-50 dark:bg-stone-950/60 rounded-xl p-3 border border-stone-200 dark:border-stone-800 text-xs space-y-1">
              <div className="font-bold text-stone-800 dark:text-stone-200 text-sm truncate">
                {book.title}
              </div>
              <div className="text-stone-500 dark:text-stone-400 truncate font-mono text-[11px]">
                ဖိုင်အမည်: {book.fileName}
              </div>
              <div className="text-stone-500 dark:text-stone-400">
                ဖိုင်အရွယ်အစား: <span className="font-semibold text-stone-700 dark:text-stone-300">{formatFileSize(book.fileSize)}</span>
              </div>
            </div>

            <p className="text-[11px] text-red-600 dark:text-red-400 mt-2 font-medium">
              * ဖျက်ပြီးပါက ဤဖိုင်ကို ပြန်လည်ရယူ၍ မရနိုင်ပါ။
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 bg-stone-50 dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            မဖျက်တော့ပါ
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isDeleting}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            {isDeleting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                <span>ဖျက်နေပါသည်...</span>
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4" />
                <span>ဖျက်မည်</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
