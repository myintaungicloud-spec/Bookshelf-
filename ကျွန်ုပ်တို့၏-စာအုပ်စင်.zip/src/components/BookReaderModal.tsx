/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Download, FileText, ExternalLink, Sun, Moon, Coffee } from 'lucide-react';
import { Book } from '../types/book';
import { formatFileSize, downloadBlob } from '../utils/formatters';

interface BookReaderModalProps {
  book: Book | null;
  isOpen: boolean;
  onClose: () => void;
}

type ReaderTheme = 'light' | 'sepia' | 'dark';

export const BookReaderModal: React.FC<BookReaderModalProps> = ({
  book,
  isOpen,
  onClose,
}) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState<number>(16);
  const [theme, setTheme] = useState<ReaderTheme>('light');
  const [epubText, setEpubText] = useState<string>('');

  useEffect(() => {
    if (!book || !isOpen) {
      if (blobUrl) {
        URL.revokeObjectURL(blobUrl);
        setBlobUrl(null);
      }
      return;
    }

    if (book.blob) {
      const url = URL.createObjectURL(book.blob);
      setBlobUrl(url);

      // If EPUB or text, read sample text
      if (book.fileType === 'epub') {
        const reader = new FileReader();
        reader.onload = (e) => {
          const res = e.target?.result as string;
          const parser = new DOMParser();
          try {
            const doc = parser.parseFromString(res, 'text/html');
            const bodyText = doc.body.textContent || res;
            setEpubText(bodyText);
          } catch {
            setEpubText(res);
          }
        };
        reader.readAsText(book.blob);
      }
    }

    return () => {
      if (blobUrl) {
        URL.revokeObjectURL(blobUrl);
      }
    };
  }, [book, isOpen]);

  if (!isOpen || !book) return null;

  const isPdf = book.fileType === 'pdf';

  const handleDownload = () => {
    if (book.blob) {
      downloadBlob(book.blob, book.fileName);
    }
  };

  const themeStyles = {
    light: 'bg-white text-stone-900',
    sepia: 'bg-[#fbf0d9] text-[#433422]',
    dark: 'bg-stone-950 text-stone-100',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/80 backdrop-blur-xs flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-stone-900 w-full max-w-4xl h-[92vh] sm:h-[88vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-200 dark:border-stone-800 mx-auto">
        {/* Top Header */}
        <div className="px-4 py-3 border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-900 flex items-center justify-between gap-3 shrink-0">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span
                className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                  isPdf
                    ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-300'
                    : 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300'
                }`}
              >
                {book.fileType.toUpperCase()}
              </span>
              <h2 className="text-sm sm:text-base font-bold text-stone-900 dark:text-stone-100 truncate">
                {book.title}
              </h2>
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400 truncate">
              {book.author} · {formatFileSize(book.fileSize)}
            </p>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Open Full Screen / New Tab (for PDF) */}
            {isPdf && blobUrl && (
              <a
                href={blobUrl}
                target="_blank"
                rel="noreferrer"
                className="min-h-[40px] px-2.5 py-1.5 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 text-xs font-medium flex items-center gap-1 transition-colors"
                title="တက်ဘ်အသစ်တွင် ဖွင့်ဖတ်မည်"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">တက်ဘ်အသစ်</span>
              </a>
            )}

            {/* Download Button */}
            <button
              onClick={handleDownload}
              className="min-h-[40px] px-3 py-1.5 rounded-xl bg-amber-900 dark:bg-amber-700 hover:bg-amber-950 dark:hover:bg-amber-600 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="ဒေါင်းလုဒ် ရယူရန်"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ဒေါင်းလုဒ်</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="min-h-[40px] min-w-[40px] rounded-xl text-stone-500 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-200 dark:hover:bg-stone-800 flex items-center justify-center transition-colors cursor-pointer"
              aria-label="ပိတ်မည်"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reader Body */}
        <div className="flex-1 overflow-hidden relative flex flex-col">
          {isPdf ? (
            /* PDF In-App Viewer */
            <div className="w-full h-full flex flex-col bg-stone-100 dark:bg-stone-950">
              {blobUrl ? (
                <iframe
                  src={`${blobUrl}#toolbar=1&navpanes=0`}
                  title={book.title}
                  className="w-full h-full border-0"
                />
              ) : (
                <div className="p-8 text-center m-auto max-w-sm">
                  <FileText className="w-12 h-12 text-stone-400 dark:text-stone-600 mx-auto mb-3" />
                  <p className="text-sm font-semibold text-stone-700 dark:text-stone-300 mb-2">
                    PDF စာရွက်စာတမ်းကို ဖွင့်နေပါသည်...
                  </p>
                  <button
                    onClick={handleDownload}
                    className="mt-3 px-4 py-2 rounded-xl bg-amber-900 dark:bg-amber-700 text-white text-xs font-medium cursor-pointer"
                  >
                    ဖိုင်ကို တိုက်ရိုက်ဒေါင်းလုဒ်လုပ်မည်
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* EPUB / Text In-App Reader */
            <div className={`w-full h-full flex flex-col ${themeStyles[theme]} transition-colors duration-200`}>
              {/* Reader Toolbar */}
              <div className="px-4 py-2 border-b border-black/10 dark:border-white/10 flex items-center justify-between text-xs shrink-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold opacity-75">စာလုံးအရွယ်အစား:</span>
                  <button
                    onClick={() => setFontSize((s) => Math.max(12, s - 2))}
                    className="w-8 h-8 rounded border border-current/20 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
                    title="စာလုံးသေးမည်"
                  >
                    A-
                  </button>
                  <span className="font-mono">{fontSize}px</span>
                  <button
                    onClick={() => setFontSize((s) => Math.min(28, s + 2))}
                    className="w-8 h-8 rounded border border-current/20 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
                    title="စာလုံးကြီးမည်"
                  >
                    A+
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setTheme('light')}
                    className={`w-7 h-7 rounded-full border flex items-center justify-center cursor-pointer ${
                      theme === 'light' ? 'ring-2 ring-amber-700' : ''
                    } bg-white text-stone-800`}
                    title="နေ့ခင်း မုဒ်"
                  >
                    <Sun className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setTheme('sepia')}
                    className={`w-7 h-7 rounded-full border flex items-center justify-center cursor-pointer ${
                      theme === 'sepia' ? 'ring-2 ring-amber-700' : ''
                    } bg-[#fbf0d9] text-[#433422]`}
                    title="မျက်စိအေး မုဒ် (Sepia)"
                  >
                    <Coffee className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`w-7 h-7 rounded-full border flex items-center justify-center cursor-pointer ${
                      theme === 'dark' ? 'ring-2 ring-amber-700' : ''
                    } bg-stone-900 text-stone-100`}
                    title="ညခင်း မုဒ် (Dark)"
                  >
                    <Moon className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Text content area */}
              <div className="flex-1 overflow-y-auto p-6 sm:p-10 max-w-2xl mx-auto leading-relaxed">
                <div className="text-center mb-8 pb-6 border-b border-black/10 dark:border-white/10">
                  <span className="text-xs uppercase font-bold tracking-widest opacity-60">
                    {book.category}
                  </span>
                  <h1 className="text-2xl font-bold mt-1 mb-2">{book.title}</h1>
                  <p className="text-sm opacity-80">စာရေးဆရာ: {book.author}</p>
                </div>

                {book.description && (
                  <div className="mb-6 p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 text-sm">
                    <div className="font-bold mb-1 opacity-75">စာအုပ်အကျဉ်းချုပ် -</div>
                    <p>{book.description}</p>
                  </div>
                )}

                <div
                  style={{ fontSize: `${fontSize}px` }}
                  className="space-y-4 whitespace-pre-wrap font-sans"
                >
                  {epubText || 'စာအုပ်ပါ အကြောင်းအရာများကို ဒေါင်းလုဒ်ရယူ၍ သင်နှစ်သက်ရာ EPUB Reader ဖြင့် ဖတ်ရှုနိုင်ပါသည်။'}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
