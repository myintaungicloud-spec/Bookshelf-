/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Download, Trash2, BookOpen, Heart, FileText, Share2 } from 'lucide-react';
import { Book } from '../types/book';
import { formatFileSize, formatBurmeseDate } from '../utils/formatters';

interface BookCardProps {
  book: Book;
  onDownload: (book: Book) => void;
  onDelete: (book: Book) => void;
  onRead: (book: Book) => void;
  onToggleFavorite: (id: string) => void;
  onShare: (book: Book) => void;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  onDownload,
  onDelete,
  onRead,
  onToggleFavorite,
  onShare,
}) => {
  const isPdf = book.fileType === 'pdf';

  return (
    <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col justify-between transition-all hover:border-stone-300 dark:hover:border-stone-700 hover:shadow-md group">
      {/* Top Cover Visual */}
      <div
        onClick={() => onRead(book)}
        className="relative h-48 w-full cursor-pointer overflow-hidden flex flex-col justify-between p-4"
        style={{
          backgroundColor: book.coverColor || '#1e3a8a',
        }}
      >
        {/* If image available */}
        {book.coverImage && (
          <img
            src={book.coverImage}
            alt={book.title}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-300"
          />
        )}

        {/* Subtle dark gradient overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-900/40 to-black/30" />

        {/* Top badges over cover */}
        <div className="relative z-10 flex items-center justify-between">
          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
              isPdf ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
            }`}
          >
            {book.fileType.toUpperCase()}
          </span>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(book.id);
            }}
            className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-xs flex items-center justify-center text-white hover:bg-black/60 transition-colors"
            title={book.isFavorite ? 'အကြိုက်ဆုံးမှ ဖယ်ထုတ်မည်' : 'အကြိုက်ဆုံးအဖြစ် မှတ်မည်'}
            aria-label="အကြိုက်ဆုံး"
          >
            <Heart className={`w-4 h-4 ${book.isFavorite ? 'fill-rose-500 text-rose-500' : 'text-white'}`} />
          </button>
        </div>

        {/* Bottom Title on Cover */}
        <div className="relative z-10 text-white">
          <span className="text-[11px] font-medium text-amber-200/90 tracking-wide block mb-0.5">
            {book.category}
          </span>
          <h3 className="text-base font-bold line-clamp-2 leading-snug drop-shadow-xs">
            {book.title}
          </h3>
          <p className="text-xs text-stone-200 truncate mt-0.5 opacity-90">
            {book.author}
          </p>
        </div>
      </div>

      {/* Card Body: File Name, Size, & Date */}
      <div className="p-3.5 space-y-2.5 flex-1 flex flex-col justify-between bg-white dark:bg-stone-900">
        <div className="space-y-1.5 text-xs text-stone-500 dark:text-stone-400">
          {/* File Name */}
          <div className="flex items-start gap-1.5">
            <FileText className="w-3.5 h-3.5 text-stone-400 dark:text-stone-500 mt-0.5 shrink-0" />
            <span className="text-stone-700 dark:text-stone-300 font-mono text-[11px] truncate flex-1" title={book.fileName}>
              {book.fileName}
            </span>
          </div>

          {/* File Size & Date */}
          <div className="flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 pt-1 border-t border-stone-100 dark:border-stone-800">
            <div>
              <span>အရွယ်အစား: </span>
              <span className="font-semibold text-stone-800 dark:text-stone-200 tabular-nums">
                {formatFileSize(book.fileSize)}
              </span>
            </div>
            <span className="text-stone-400 dark:text-stone-500">{formatBurmeseDate(book.addedAt)}</span>
          </div>
        </div>

        {/* Card Actions: Read, Download, Delete, Share */}
        <div className="flex items-center justify-between gap-1 pt-2 border-t border-stone-100 dark:border-stone-800">
          <button
            type="button"
            onClick={() => onRead(book)}
            className="min-h-[40px] flex-1 px-2.5 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
            title="ဖတ်ရှုမည်"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>ဖတ်မည်</span>
          </button>

          <button
            type="button"
            onClick={() => onDownload(book)}
            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-amber-900 dark:bg-amber-700 hover:bg-amber-950 dark:hover:bg-amber-600 text-white text-xs font-semibold flex items-center justify-center gap-1 shadow-2xs transition-colors cursor-pointer"
            title="ဒေါင်းလုဒ်ရယူရန်"
          >
            <Download className="w-3.5 h-3.5" />
            <span>ဒေါင်းလုဒ်</span>
          </button>

          <button
            type="button"
            onClick={() => onShare(book)}
            className="min-h-[40px] min-w-[40px] rounded-xl text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center justify-center transition-colors"
            title="မျှဝေမည်"
            aria-label="မျှဝေမည်"
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => onDelete(book)}
            className="min-h-[40px] min-w-[40px] rounded-xl text-stone-400 dark:text-stone-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center justify-center transition-colors cursor-pointer"
            title="ဖျက်မည်"
            aria-label="ဖျက်မည်"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
